Author: AldaneRussell
Datecreated: 1/5/2022
Course: ITT103
Purpose:"This pseudocodes purpose is to create a system that can calculate the commision received by a salesperson based on certain factors and criteria to be met first"


#Function
    def calccommision()
    commision=(Sales_Amnt * rate)
    ENDFUNCTION
    
#Input variables
    Sales_prson=float(input("Please enter the sale person's number"))
    READ Sales_prson
    Sales_Amnt=float(input("Please enter the number of sales"))
    READ Sales_Amnt
    class=input("Please enter the sale person's class")
    READ class
    
    #SET count = 1
    #DECLARE count as INTEGER
    count=int(1)

    while count < 4 DO
         calccommision()
    
        if class = "1" AND Sales_Amnt <= 1000 THEN
            commision = Sales_Amnt*0.06
            
            elif class = "1" AND Sales_Amnt > 1000 AND sales < 2000 THEN
                commision = Sales_Amnt*0.07
            elif class = "1" AND Sales_Amnt => 2000 THEN
                commision = Sales_Amnt*0.10
            
        ELSE
            if class = "2" AND Sales_Amnt < 1000 THEN
                commision = Sales_Amnt*0.04
            if class = "2" AND Sales_Amnt => 1000 THEN
                commision = Sales_Amnt*0.06
                ENDIF
        ELSE
            IF class = "3" AND classSales_Amnt =() THEN
                commision = Sales_Amnt*0.045
                ENDIF
        ELSE

        write "Try Again"
                    
            ENDIF

        print("The salesperson","has acquired this commision-", commision)
        
        
        count = count + 1      
        
    ENDWHILE

